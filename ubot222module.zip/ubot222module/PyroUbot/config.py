import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "999"))

DEVS = list(map(int, os.getenv("DEVS", "7520490068").split()))

API_ID = int(os.getenv("API_ID", "39676076"))

API_HASH = os.getenv("API_HASH", "0fdba46e814ffe89f5450de4a3c20cf4")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8400137645:AAFobc7MHNWmvmCvgUIxArwNpeTX0wwaI5M")

OWNER_ID = int(os.getenv("OWNER_ID", "7520490068"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002886184276").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://yogzpribadiubot_db_user:yogzzpribadi@cluster0.pq50oxk.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002671518601"))
