
```
apt update && apt upgrade -y
```
```
git clone https://github.com/MachaOfficial/ubotMacha
```
```
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
```
```
cd ubotMacha
```
```
bash installnode.sh && apt install python3.10-venv.
```
```
python3 -m venv ubotMacha && source ubotMacha/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
python3 -m PyroUbot
```
